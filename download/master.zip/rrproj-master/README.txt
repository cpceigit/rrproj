This file is README for GitBash
Contents:
* hello.txt

